"""FMEA (Failure Mode and Effects Analysis) module."""

from .simple_fmea import SimpleFMEAAnalyzer

__all__ = [
    "SimpleFMEAAnalyzer",
]