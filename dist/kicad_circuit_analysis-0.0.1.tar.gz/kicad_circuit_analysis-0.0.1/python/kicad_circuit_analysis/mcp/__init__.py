"""MCP server interface for kicad-circuit-analysis."""

from .server import create_server, main

__all__ = [
    "create_server",
    "main",
]